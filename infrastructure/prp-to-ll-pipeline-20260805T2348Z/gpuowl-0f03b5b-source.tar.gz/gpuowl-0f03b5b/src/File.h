// Copyright (C) Mihai Preda.

#pragma once

#include "common.h"
#include "log.h"

#include <cstdio>
#include <cstdarg>
#include <cassert>
#ifndef _MSC_VER                // unistd.h does not exist for MSVC
#include <unistd.h>
#endif
#include <filesystem>
#include <utility>
#include <vector>
#include <string>
#include <optional>

#if defined(_WIN32) || defined(__WIN32__)
#include <io.h>
#endif

#ifdef __APPLE__
#include <fcntl.h>
#endif

#if defined(_DEFAULT_SOURCE) || defined(_BSD_SOURCE)
#define HAS_SETLINEBUF 1
#else
#define HAS_SETLINEBUF 0
#endif

//! Macros for __attribute__ compiler/crossplatform support
#ifndef _MSC_VER
#define FORMAT_PRINTF(fmt_idx, arg_idx) __attribute__((format(printf, fmt_idx, arg_idx)))
#define FORMAT_SCANF(fmt_idx, arg_idx) __attribute__((format(scanf, fmt_idx, arg_idx)))
#else
#define FORMAT_PRINTF(fmt_idx, arg_idx)
#define FORMAT_SCANF(fmt_idx, arg_idx)
#endif

namespace fs = std::filesystem;

struct CRCError {
  std::string name;
};

struct ReadError {
  std::string name;
};

struct WriteError {
  std::string name;
};

class File {
  FILE* f = nullptr;
  const bool readOnly;
  
  File(const fs::path &path, const string& mode, bool throwOnError);

  bool readNoThrow(void* data, size_t nBytes) const { return fread(data, nBytes, 1, this->get()); }
  
  void read(void* data, size_t nBytes) const {
    if (!readNoThrow(data, nBytes)) { throw ReadError{name}; }
  }

  void datasync() {
    fflush(f);
#ifdef _MSC_VER
// We'd really like to use FlushFileBuffers(h), but we do not have easy access to the Windows file handle.
// We might could get that by getting the pathname and opening the file with native Windows routines.
#elif defined(_WIN32) || defined(__WIN32__)
    _commit(fileno(f));
#elif defined(__APPLE__)
    fcntl(fileno(f), F_FULLFSYNC, 0);
#elif defined(__MINGW32__) || defined(__MINGW64__)
    fdatasync(fileno(f));
#elif defined(__MSYS__) // MSYS2 using CLANG64 compiler
#define fileno(__F) ((__F)->_file)
    fsync(fileno(f)); // This doesn't work
#undef fileno
#else
    fdatasync(fileno(f));
#endif
  }

public:
  const std::string name;

  static u64 size(const fs::path& name);

  static File openRead(const fs::path& name) { return File{name, "rb", false}; }
  static File openReadThrow(const fs::path& name) { return File{name, "rb", true}; }
  
  static File openWrite(const fs::path& name) { return File{name, "wb", true}; }
  
  static File openAppend(const fs::path &name) { return File{name, "ab", true}; }
  
  static void append(const fs::path& name, std::string_view text) { File::openAppend(name).write(text); }

  File() :  readOnly{true} {}

  File(FILE* f, string  name) : f{f}, readOnly{false}, name{std::move(name)} {}
  
  File(File&& other)  noexcept : f{other.f}, readOnly{other.readOnly}, name{other.name} { other.f = nullptr; }
  
  File& operator=(File&& other) noexcept ;

  File(const File& other) = delete;
  File& operator=(const File& other) = delete;

  ~File();
  
  class It {
  public:
    explicit It(File& file) : file{&file}, line{file ? file.maybeReadLine() : nullopt} {}
    It() = default;

    bool operator==(const It& rhs) const { return !line && !rhs.line; }
    bool operator!=(const It& rhs) const { return !(*this == rhs); }
    
    It& operator++() {
      line = file->maybeReadLine();
      return *this;
    }
    
    string operator*() { return *line; }

  private:
    File *file{};
    optional<string> line;
  };

  It begin() { return It{*this}; }
  It end() { return It{}; }
  
  template<typename T>
  void write(const vector<T>& v) const { write(v.data(), v.size() * sizeof(T)); }

  template<typename T>
  void write(const T& x) const { write(&x, sizeof(T)); }

  void write(const void* data, size_t nBytes) const {
    if (!fwrite(data, nBytes, 1, this->get())) { throw WriteError{name}; }
  }
  
  void seek(long offset, int whence = SEEK_SET) {
    int const ret = fseek(this->get(), offset, whence);
    if (ret) { throw ReadError{name}; }
      // throw(std::ios_base::failure(("fseek: "s + to_string(ret)).c_str()));
  }

  void flush() { fflush(this->get()); }
  
  int printf(const char *fmt, ...) const FORMAT_PRINTF(2, 3) {
    va_list va;
    va_start(va, fmt);
    int const ret = vfprintf(f, fmt, va);
    va_end(va);

#if !HAS_LINEBUF
    fflush(f);
#endif

    return ret;
  }

  int scanf(const char *fmt, ...) FORMAT_SCANF(2, 3) {
    va_list va;
    va_start(va, fmt);
    int const ret = vfscanf(f, fmt, va);
    va_end(va);
    return ret;
  }
  
  void write(const string& s) { write(string_view(s)); }
  void write(const char* s) { write(string_view(s)); }
  void write(string_view s) { write(s.data(), s.size()); }

  operator bool() const { return f != nullptr; }
  [[nodiscard]] FILE* get() const { return f; }

  [[nodiscard]] long ftell() const {
    long const pos = ::ftell(this->get());
    assert(pos >= 0);
    return pos;
  }

  long seekEnd() {
    seek(0, SEEK_END);
    return ftell();
  }
  
  long size() {
    long const savePos = ftell();
    long const retSize = seekEnd();
    seek(savePos);
    return retSize;
  }

  bool empty() { return size() == 0; }

  // Returns newline-ended line.
  std::string readLine() {
    char buf[1024];
    buf[0] = 0;
    bool const ok = fgets(buf, sizeof(buf), this->get());
    if (!ok) { return ""; }  // EOF or error
    string line = buf;
    if (line.empty() || line.back() != '\n') {
      log("%s : line \"%s\" does not end with a newline\n", name.c_str(), line.c_str());
      throw ReadError{name};
    }
    return line;
  }

  std::optional<std::string> maybeReadLine() {
    std::string line = readLine();
    if (line.empty()) { return std::nullopt; }
    return line;
  }

  template<typename T>
  [[nodiscard]] std::vector<T> read(size_t nWords) const {
    vector<T> ret;
    ret.resize(nWords);
    read(ret.data(), nWords * sizeof(T));
    return ret;
  }

  template<typename T>
  [[nodiscard]] std::vector<T> readChecked(size_t nWords) const {
    u32 const expectedCRC = read<u32>(1)[0];
    return readWithCRC<T>(nWords, expectedCRC);
  }

  template<typename T>
  void writeChecked(const vector<T>& data) const {
    write(u32(crc32(data)));
    write(data);
  }

  template<typename T>
  [[nodiscard]] std::vector<T> readWithCRC(size_t nWords, u32 crc) const {
    auto data = read<T>(nWords);
    if (crc != crc32(data)) {
      log("File '%s' : CRC: expected %u, actual %u\n", name.c_str(), crc, crc32(data));
      throw CRCError{name};
    }    
    return data;
  }

  std::vector<u32> readBytesLE(size_t nBytes) {
    assert(nBytes > 0);
    size_t const nWords = (nBytes - 1) / 4 + 1;
    vector<u32> data(nWords);
    read(data.data(), nBytes);
    return data;
  }

  size_t readUpTo(void* data, size_t nUpToBytes) { return fread(data, 1, nUpToBytes, this->get()); }

  string readAll() {
    u64 const sz = size();
    return {read<char>(sz).data(), sz};
  }
};
